"use client"

import { featuredArticles } from "@/lib/data"
import { Badge } from "@/components/ui/badge"
import { Clock, User } from "lucide-react"
import { formatDate } from "@/lib/utils"

export function HeroSection() {
  const mainArticle = featuredArticles[0]
  const sideArticles = featuredArticles.slice(1)

  return (
    <section className="py-6 md:py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Featured Article */}
          <div className="lg:col-span-8">
            <article className="group relative overflow-hidden rounded-2xl bg-white shadow-sm border border-navy-100">
              <div className="relative aspect-[16/9] overflow-hidden">
                <img
                  src={mainArticle.coverImage}
                  alt={mainArticle.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/40 to-transparent" />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-navy-900 text-white border-0 text-xs uppercase tracking-wider">
                    {mainArticle.category}
                  </Badge>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
                  <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-3 leading-tight group-hover:text-navy-200 transition-colors">
                    <a href={`/artikel/${mainArticle.slug}`} className="hover:underline decoration-2 underline-offset-4">
                      {mainArticle.title}
                    </a>
                  </h2>
                  <p className="text-navy-100 text-sm md:text-base mb-4 line-clamp-2 max-w-2xl">
                    {mainArticle.excerpt}
                  </p>
                  <div className="flex items-center gap-4 text-navy-200 text-sm">
                    <div className="flex items-center gap-1.5">
                      <User className="h-4 w-4" />
                      <span>{mainArticle.author}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="h-4 w-4" />
                      <span>{mainArticle.readTime} menit baca</span>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          </div>

          {/* Side Featured Articles */}
          <div className="lg:col-span-4 space-y-4">
            {sideArticles.map((article, index) => (
              <article key={article.id} className="group bg-white rounded-xl overflow-hidden border border-navy-100 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex gap-4 p-4">
                  <div className="relative w-24 h-24 flex-shrink-0 overflow-hidden rounded-lg">
                    <img
                      src={article.coverImage}
                      alt={article.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <Badge variant="secondary" className="mb-2 text-[10px] uppercase">
                      {article.category}
                    </Badge>
                    <h3 className="font-semibold text-navy-900 text-sm leading-snug mb-2 line-clamp-2 group-hover:text-navy-700 transition-colors">
                      <a href={`/artikel/${article.slug}`}>
                        {article.title}
                      </a>
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-navy-500">
                      <Clock className="h-3 w-3" />
                      <span>{article.readTime} menit</span>
                    </div>
                  </div>
                </div>
              </article>
            ))}

            {/* Newsletter Mini */}
            <div className="bg-navy-900 rounded-xl p-6 text-white">
              <h3 className="font-bold text-lg mb-2">Newsletter ArekMalang</h3>
              <p className="text-navy-200 text-sm mb-4">Dapatkan berita terbaru langsung di inbox Anda setiap pagi.</p>
              <div className="flex gap-2">
                <input 
                  type="email" 
                  placeholder="Email Anda" 
                  className="flex-1 px-3 py-2 rounded-md text-navy-900 text-sm focus:outline-none focus:ring-2 focus:ring-navy-400"
                />
                <button className="px-4 py-2 bg-white text-navy-900 rounded-md text-sm font-semibold hover:bg-navy-50 transition-colors">
                  Daftar
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
