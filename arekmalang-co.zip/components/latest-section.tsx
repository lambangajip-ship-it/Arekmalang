"use client"

import { latestArticles, categories } from "@/lib/data"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, User, ChevronRight } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

export function LatestSection() {
  const [selectedCategory, setSelectedCategory] = useState("all")

  const filteredArticles = selectedCategory === "all" 
    ? latestArticles 
    : latestArticles.filter(a => a.category.toLowerCase() === selectedCategory)

  return (
    <section className="py-8 md:py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-navy-900 mb-2">Berita Terbaru</h2>
            <p className="text-navy-600">Update informasi terkini dari Malang Raya</p>
          </div>
          <Button variant="outline" className="border-navy-200 text-navy-700 hover:bg-navy-50 w-fit">
            Lihat Semua
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-6 scrollbar-hide">
          <button
            onClick={() => setSelectedCategory("all")}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors",
              selectedCategory === "all" 
                ? "bg-navy-900 text-white" 
                : "bg-white text-navy-700 border border-navy-200 hover:bg-navy-50"
            )}
          >
            Semua
          </button>
          {categories.slice(0, 6).map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.slug)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors",
                selectedCategory === cat.slug
                  ? "bg-navy-900 text-white"
                  : "bg-white text-navy-700 border border-navy-200 hover:bg-navy-50"
              )}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => (
            <article 
              key={article.id} 
              className="group bg-white rounded-xl overflow-hidden border border-navy-100 shadow-sm hover:shadow-lg transition-all duration-300"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={article.coverImage}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute top-3 left-3">
                  <Badge className="bg-white/90 text-navy-900 backdrop-blur-sm border-0 text-xs">
                    {article.category}
                  </Badge>
                </div>
              </div>
              <div className="p-5">
                <h3 className="font-bold text-navy-900 text-lg leading-snug mb-3 line-clamp-2 group-hover:text-navy-700 transition-colors">
                  <a href={`/artikel/${article.slug}`}>
                    {article.title}
                  </a>
                </h3>
                <p className="text-navy-600 text-sm mb-4 line-clamp-2">
                  {article.excerpt}
                </p>
                <div className="flex items-center justify-between text-xs text-navy-500 pt-4 border-t border-navy-100">
                  <div className="flex items-center gap-1.5">
                    <User className="h-3.5 w-3.5" />
                    <span className="font-medium text-navy-700">{article.author}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5" />
                    <span>{article.readTime} menit</span>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-10">
          <Button size="lg" className="bg-navy-900 hover:bg-navy-800 px-8">
            Muat Lebih Banyak
          </Button>
        </div>
      </div>
    </section>
  )
}
