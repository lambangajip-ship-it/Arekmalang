import { cn } from "@/lib/utils"

interface BadgeProps {
  children: React.ReactNode
  className?: string
  variant?: "default" | "secondary" | "outline"
}

export function Badge({ children, className, variant = "default" }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors",
        {
          "bg-navy-900 text-white hover:bg-navy-800": variant === "default",
          "bg-navy-100 text-navy-900 hover:bg-navy-200": variant === "secondary",
          "border border-navy-200 text-navy-900 hover:bg-navy-50": variant === "outline",
        },
        className
      )}
    >
      {children}
    </span>
  )
}
