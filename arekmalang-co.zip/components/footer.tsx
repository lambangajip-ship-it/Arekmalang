import { categories } from "@/lib/data"
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-navy-950 text-white">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <span className="text-navy-900 font-bold text-lg">A</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">ArekMalang</h3>
                <span className="text-xs text-navy-300">.co</span>
              </div>
            </div>
            <p className="text-navy-300 text-sm mb-6 leading-relaxed">
              Portal berita independen yang menyajikan informasi terkini seputar Malang Raya dengan integritas dan profesionalisme.
            </p>
            <div className="flex gap-3">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                <a 
                  key={i}
                  href="#" 
                  className="w-9 h-9 bg-navy-900 rounded-lg flex items-center justify-center hover:bg-navy-800 transition-colors"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-4">Kategori</h4>
            <ul className="space-y-2">
              {categories.slice(0, 6).map((cat) => (
                <li key={cat.id}>
                  <a 
                    href={`/kategori/${cat.slug}`}
                    className="text-navy-300 hover:text-white transition-colors text-sm"
                  >
                    {cat.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Information */}
          <div>
            <h4 className="font-bold text-lg mb-4">Informasi</h4>
            <ul className="space-y-2 text-sm text-navy-300">
              <li><a href="#" className="hover:text-white transition-colors">Tentang Kami</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Redaksi</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Pedoman Media Siber</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Karir</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Beriklan</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-4">Hubungi Kami</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3 text-navy-300">
                <MapPin className="h-5 w-5 flex-shrink-0 mt-0.5" />
                <span>Jl. Simpang Gading No. 12<br />Malang, Jawa Timur 65112</span>
              </li>
              <li className="flex items-center gap-3 text-navy-300">
                <Phone className="h-4 w-4 flex-shrink-0" />
                <span>(0341) 123456</span>
              </li>
              <li className="flex items-center gap-3 text-navy-300">
                <Mail className="h-4 w-4 flex-shrink-0" />
                <span>redaksi@arekmalang.co</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
    <div className="border-t border-navy-900">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-navy-400">
            <p>© 2024 ArekMalang.co. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Terms</a>
              <a href="#" className="hover:text-white transition-colors">Privacy</a>
              <a href="#" className="hover:text-white transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
