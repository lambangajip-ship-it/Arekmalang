"use client"

import { trendingArticles } from "@/lib/data"
import { TrendingUp, Clock, Eye } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export function TrendingSection() {
  return (
    <section className="py-6 bg-navy-50/50">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-2 mb-6">
          <div className="p-2 bg-navy-900 rounded-lg">
            <TrendingUp className="h-5 w-5 text-white" />
          </div>
          <h2 className="text-xl font-bold text-navy-900">Berita Trending</h2>
          <div className="flex-1 h-px bg-navy-200 ml-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {trendingArticles.map((article, index) => (
            <article 
              key={article.id} 
              className="group bg-white rounded-xl p-4 border border-navy-100 shadow-sm hover:shadow-md transition-all hover:-translate-y-1"
            >
              <div className="flex items-start gap-4">
                <span className="text-3xl font-bold text-navy-200 group-hover:text-navy-900 transition-colors">
                  {String(index + 1).padStart(2, '0')}
                </span>
                <div className="flex-1">
                  <Badge variant="outline" className="mb-2 text-[10px]">
                    {article.category}
                  </Badge>
                  <h3 className="font-semibold text-navy-900 text-sm leading-snug mb-2 line-clamp-2 group-hover:text-navy-700 transition-colors">
                    <a href={`/artikel/${article.slug}`}>
                      {article.title}
                    </a>
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-navy-500">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {article.readTime} menit
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      {Math.floor(Math.random() * 10 + 1)}K dibaca
                    </span>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
