"use client"

import { useState } from "react"
import { Menu, X, Search, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { categories } from "@/lib/data"
import { cn } from "@/lib/utils"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [activeCategory, setActiveCategory] = useState("all")

  return (
    <header className="sticky top-0 z-50 w-full border-b border-navy-100 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      {/* Top Bar */}
      <div className="bg-navy-900 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-xs">
          <div className="flex items-center gap-4">
            <span>Senin, 12 Februari 2024</span>
            <span className="hidden sm:inline text-navy-300">|</span>
            <span className="hidden sm:inline text-navy-200">Edisi Malang Raya</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="hover:text-navy-300 transition-colors">Login</button>
            <span className="text-navy-300">|</span>
            <button className="hover:text-navy-300 transition-colors">Daftar</button>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <button 
              className="lg:hidden p-2 -ml-2 hover:bg-navy-50 rounded-md"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="h-5 w-5 text-navy-900" /> : <Menu className="h-5 w-5 text-navy-900" />}
            </button>
            <a href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-navy-900 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">A</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl font-bold text-navy-900 leading-none">ArekMalang</h1>
                <span className="text-xs text-navy-600 font-medium">.co</span>
              </div>
            </a>
          </div>

          {/* Desktop Categories */}
          <nav className="hidden lg:flex items-center gap-1">
            <a
              href="/"
              className={cn(
                "px-4 py-2 text-sm font-medium rounded-md transition-colors",
                activeCategory === "all" ? "bg-navy-100 text-navy-900" : "text-navy-700 hover:bg-navy-50"
              )}
            >
              Beranda
            </a>
            {categories.slice(0, 6).map((cat) => (
              <a
                key={cat.id}
                href={`/kategori/${cat.slug}`}
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap",
                  activeCategory === cat.slug ? "bg-navy-100 text-navy-900" : "text-navy-700 hover:bg-navy-50"
                )}
              >
                {cat.name}
              </a>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <a 
              href="/cari"
              className="p-2 hover:bg-navy-50 rounded-full transition-colors"
            >
              <Search className="h-5 w-5 text-navy-700" />
            </a>
            <button className="p-2 hover:bg-navy-50 rounded-full transition-colors relative">
              <Bell className="h-5 w-5 text-navy-700" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <Button size="sm" className="hidden sm:flex bg-navy-900 hover:bg-navy-800">
              Langganan
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden border-t border-navy-100 bg-white">
          <div className="container mx-auto px-4 py-4 space-y-2">
            <a 
              href="/"
              className="block w-full text-left px-4 py-3 text-navy-900 font-medium bg-navy-50 rounded-md"
            >
              Beranda
            </a>
            {categories.map((cat) => (
              <a
                key={cat.id}
                href={`/kategori/${cat.slug}`}
                className="block w-full text-left px-4 py-3 text-navy-700 hover:bg-navy-50 rounded-md transition-colors"
              >
                {cat.name}
              </a>
            ))}
            <hr className="border-navy-100 my-2" />
            <a
              href="/cari"
              className="flex items-center gap-2 w-full text-left px-4 py-3 text-navy-700 hover:bg-navy-50 rounded-md transition-colors"
            >
              <Search className="h-4 w-4" />
              Cari Berita
            </a>
          </div>
        </div>
      )}
    </header>
  )
}
