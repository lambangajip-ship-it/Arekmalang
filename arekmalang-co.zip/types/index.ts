export interface Article {
  id: string
  title: string
  excerpt: string
  content?: string
  slug: string
  coverImage: string
  category: string
  author: string
  publishedAt: string
  readTime: number
  featured?: boolean
  trending?: boolean
}

export interface Category {
  id: string
  name: string
  slug: string
  count: number
}
