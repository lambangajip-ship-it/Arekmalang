"use client"

import { useState } from "react"
import { articles } from "@/lib/data"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Clock, User, Search, X } from "lucide-react"

export default function SearchPage() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState(articles)
  const [hasSearched, setHasSearched] = useState(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setHasSearched(true)

    if (!query.trim()) {
      setResults(articles)
      return
    }

    const filtered = articles.filter(
      (article) =>
        article.title.toLowerCase().includes(query.toLowerCase()) ||
        article.excerpt.toLowerCase().includes(query.toLowerCase()) ||
        article.category.toLowerCase().includes(query.toLowerCase())
    )
    setResults(filtered)
  }

  const clearSearch = () => {
    setQuery("")
    setResults(articles)
    setHasSearched(false)
  }

  return (
    <main className="min-h-screen bg-white">
      <Navigation />

      {/* Search Header */}
      <section className="bg-navy-900 text-white py-12">
        <div className="container mx-auto px-4 max-w-3xl">
          <h1 className="text-3xl md:text-4xl font-bold mb-6 text-center">
            Cari Berita
          </h1>
          <form onSubmit={handleSearch} className="relative">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-navy-400" />
              <Input
                type="text"
                placeholder="Cari berita, topik, atau kata kunci..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-12 pr-12 py-6 text-lg bg-white text-navy-900 border-0 rounded-xl shadow-lg"
              />
              {query && (
                <button
                  type="button"
                  onClick={clearSearch}
                  className="absolute right-4 top-1/2 -translate-y-1/2"
                >
                  <X className="h-5 w-5 text-navy-400 hover:text-navy-600" />
                </button>
              )}
            </div>
            <Button 
              type="submit"
              className="mt-4 w-full bg-white text-navy-900 hover:bg-navy-50 font-semibold py-6"
            >
              <Search className="h-5 w-5 mr-2" />
              Cari Sekarang
            </Button>
          </form>
        </div>
      </section>

      {/* Results */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {/* Results Count */}
          {hasSearched && (
            <div className="mb-8">
              <p className="text-navy-600">
                Ditemukan <span className="font-bold text-navy-900">{results.length}</span> hasil 
                {query && (
                  <span>
                    {" "}untuk "<span className="font-semibold">{query}</span>"
                  </span>
                )}
              </p>
            </div>
          )}

          {/* Results Grid */}
          {results.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((article) => (
                <article 
                  key={article.id} 
                  className="group bg-white rounded-xl overflow-hidden border border-navy-100 shadow-sm hover:shadow-lg transition-all duration-300"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={article.coverImage}
                      alt={article.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-navy-900 text-white border-0">
                        {article.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-5">
                    <h2 className="font-bold text-navy-900 text-lg leading-snug mb-3 line-clamp-2 group-hover:text-navy-700 transition-colors">
                      <a href={`/artikel/${article.slug}`}>
                        {article.title}
                      </a>
                    </h2>
                    <p className="text-navy-600 text-sm mb-4 line-clamp-2">
                      {article.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-xs text-navy-500 pt-4 border-t border-navy-100">
                      <div className="flex items-center gap-1.5">
                        <User className="h-3.5 w-3.5" />
                        <span className="font-medium text-navy-700">{article.author}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{article.readTime} menit</span>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-10 w-10 text-navy-400" />
              </div>
              <h3 className="text-xl font-bold text-navy-900 mb-2">
                Tidak ada hasil
              </h3>
              <p className="text-navy-600 mb-6">
                Coba kata kunci lain atau periksa ejaan Anda.
              </p>
              <Button onClick={clearSearch} variant="outline" className="border-navy-200">
                Lihat Semua Artikel
              </Button>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </main>
  )
}
