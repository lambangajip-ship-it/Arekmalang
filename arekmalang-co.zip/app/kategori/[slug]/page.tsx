import { articles, categories } from "@/lib/data"
import { notFound } from "next/navigation"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, User, ChevronRight } from "lucide-react"

interface CategoryPageProps {
  params: {
    slug: string
  }
}

export function generateStaticParams() {
  return categories.map((category) => ({
    slug: category.slug,
  }))
}

export function generateMetadata({ params }: CategoryPageProps) {
  const category = categories.find((c) => c.slug === params.slug)

  if (!category) {
    return {
      title: "Kategori Tidak Ditemukan - ArekMalang.co",
    }
  }

  return {
    title: `${category.name} - ArekMalang.co`,
    description: `Berita ${category.name} terbaru dari Malang Raya`,
  }
}

export default function CategoryPage({ params }: CategoryPageProps) {
  const category = categories.find((c) => c.slug === params.slug)

  if (!category) {
    notFound()
  }

  const categoryArticles = articles.filter(
    (a) => a.category.toLowerCase() === category.name.toLowerCase()
  )

  return (
    <main className="min-h-screen bg-white">
      <Navigation />

      {/* Category Header */}
      <section className="bg-navy-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 text-navy-300 text-sm mb-4">
            <a href="/" className="hover:text-white">Beranda</a>
            <ChevronRight className="h-4 w-4" />
            <span className="text-white">{category.name}</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{category.name}</h1>
          <p className="text-navy-200 text-lg max-w-2xl">
            Kumpulan berita terbaru seputar {category.name} di Malang Raya dan sekitarnya.
          </p>
          <div className="mt-6 flex items-center gap-4">
            <span className="px-4 py-2 bg-navy-800 rounded-full text-sm">
              {category.count} Artikel
            </span>
            <span className="px-4 py-2 bg-navy-800 rounded-full text-sm">
              Update Terbaru
            </span>
          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {categoryArticles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categoryArticles.map((article) => (
                <article 
                  key={article.id} 
                  className="group bg-white rounded-xl overflow-hidden border border-navy-100 shadow-sm hover:shadow-lg transition-all duration-300"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={article.coverImage}
                      alt={article.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-navy-900 text-white border-0">
                        {article.category}
                      </Badge>
                    </div>
                  </div>
                  <div className="p-5">
                    <h2 className="font-bold text-navy-900 text-lg leading-snug mb-3 line-clamp-2 group-hover:text-navy-700 transition-colors">
                      <a href={`/artikel/${article.slug}`}>
                        {article.title}
                      </a>
                    </h2>
                    <p className="text-navy-600 text-sm mb-4 line-clamp-2">
                      {article.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-xs text-navy-500 pt-4 border-t border-navy-100">
                      <div className="flex items-center gap-1.5">
                        <User className="h-3.5 w-3.5" />
                        <span className="font-medium text-navy-700">{article.author}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{article.readTime} menit</span>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-navy-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-4xl">📰</span>
              </div>
              <h3 className="text-xl font-bold text-navy-900 mb-2">
                Belum ada artikel
              </h3>
              <p className="text-navy-600">
                Artikel dalam kategori ini akan segera hadir.
              </p>
            </div>
          )}

          {/* Pagination */}
          {categoryArticles.length > 0 && (
            <div className="flex justify-center mt-12 gap-2">
              <Button variant="outline" disabled className="border-navy-200">
                Sebelumnya
              </Button>
              <Button className="bg-navy-900 hover:bg-navy-800">
                1
              </Button>
              <Button variant="outline" className="border-navy-200 hover:bg-navy-50">
                2
              </Button>
              <Button variant="outline" className="border-navy-200 hover:bg-navy-50">
                3
              </Button>
              <Button variant="outline" className="border-navy-200 hover:bg-navy-50">
                Selanjutnya
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Other Categories */}
      <section className="py-12 bg-navy-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-navy-900 mb-6">Kategori Lainnya</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories
              .filter((c) => c.slug !== params.slug)
              .slice(0, 4)
              .map((cat) => (
                <a
                  key={cat.id}
                  href={`/kategori/${cat.slug}`}
                  className="group bg-white p-6 rounded-xl border border-navy-100 hover:border-navy-300 hover:shadow-md transition-all"
                >
                  <h3 className="font-bold text-navy-900 group-hover:text-navy-700">
                    {cat.name}
                  </h3>
                  <p className="text-sm text-navy-600 mt-1">{cat.count} artikel</p>
                </a>
              ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
