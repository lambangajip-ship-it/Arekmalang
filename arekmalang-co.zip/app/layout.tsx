import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ArekMalang.co - Portal Berita Malang Raya",
  description: "Portal berita independen yang menyajikan informasi terkini seputar Malang Raya dengan integritas dan profesionalisme.",
  keywords: "berita malang, portal berita malang, arek malang, berita jawa timur, malang raya",
  authors: [{ name: "ArekMalang.co" }],
  openGraph: {
    title: "ArekMalang.co - Portal Berita Malang Raya",
    description: "Portal berita independen yang menyajikan informasi terkini seputar Malang Raya",
    type: "website",
    locale: "id_ID",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body className="antialiased min-h-screen bg-white">
        {children}
      </body>
    </html>
  );
}
