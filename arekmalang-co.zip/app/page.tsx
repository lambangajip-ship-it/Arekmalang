import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { TrendingSection } from "@/components/trending-section"
import { LatestSection } from "@/components/latest-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <TrendingSection />
      <LatestSection />
      <Footer />
    </main>
  )
}
