import { articles } from "@/lib/data"
import { notFound } from "next/navigation"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, User, Calendar, Share2, Bookmark, MessageCircle } from "lucide-react"
import { formatDate } from "@/lib/utils"

interface ArticlePageProps {
  params: {
    slug: string
  }
}

export function generateStaticParams() {
  return articles.map((article) => ({
    slug: article.slug,
  }))
}

export function generateMetadata({ params }: ArticlePageProps) {
  const article = articles.find((a) => a.slug === params.slug)

  if (!article) {
    return {
      title: "Artikel Tidak Ditemukan - ArekMalang.co",
    }
  }

  return {
    title: `${article.title} - ArekMalang.co`,
    description: article.excerpt,
    openGraph: {
      title: article.title,
      description: article.excerpt,
      images: [article.coverImage],
    },
  }
}

export default function ArticlePage({ params }: ArticlePageProps) {
  const article = articles.find((a) => a.slug === params.slug)

  if (!article) {
    notFound()
  }

  // Find related articles (same category, exclude current)
  const relatedArticles = articles
    .filter((a) => a.category === article.category && a.id !== article.id)
    .slice(0, 3)

  return (
    <main className="min-h-screen bg-white">
      <Navigation />

      <article className="pt-6">
        {/* Header Section */}
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-navy-500 mb-4">
            <a href="/" className="hover:text-navy-900">Beranda</a>
            <span>/</span>
            <a href={`/kategori/${article.category.toLowerCase()}`} className="hover:text-navy-900">
              {article.category}
            </a>
            <span>/</span>
            <span className="text-navy-900 truncate">{article.title}</span>
          </nav>

          {/* Category Badge */}
          <Badge className="mb-4 bg-navy-900 text-white hover:bg-navy-800">
            {article.category}
          </Badge>

          {/* Title */}
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-navy-900 mb-6 leading-tight">
            {article.title}
          </h1>

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-6 text-sm text-navy-600 mb-8 pb-8 border-b border-navy-100">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-navy-100 rounded-full flex items-center justify-center">
                <User className="h-5 w-5 text-navy-700" />
              </div>
              <div>
                <p className="font-semibold text-navy-900">{article.author}</p>
                <p className="text-xs">Jurnalis</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>{formatDate(article.publishedAt)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>{article.readTime} menit baca</span>
            </div>
          </div>
        </div>

        {/* Cover Image */}
        <div className="container mx-auto px-4 max-w-5xl mb-8">
          <div className="relative aspect-[21/9] rounded-2xl overflow-hidden">
            <img
              src={article.coverImage}
              alt={article.title}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="flex gap-8">
            {/* Main Content */}
            <div className="flex-1">
              {/* Share Buttons */}
              <div className="flex items-center gap-3 mb-8">
                <span className="text-sm text-navy-600">Bagikan:</span>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Share2 className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Bookmark className="h-4 w-4" />
                </Button>
              </div>

              {/* Article Body */}
              <div className="prose prose-lg max-w-none prose-headings:text-navy-900 prose-p:text-navy-700 prose-a:text-navy-900">
                <p className="text-xl leading-relaxed text-navy-700 mb-6 font-medium">
                  {article.excerpt}
                </p>

                <p className="mb-4">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do 
                  eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim 
                  ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut 
                  aliquip ex ea commodo consequat.
                </p>

                <p className="mb-4">
                  Duis aute irure dolor in reprehenderit in voluptate velit esse 
                  cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat 
                  cupidatat non proident, sunt in culpa qui officia deserunt mollit 
                  anim id est laborum.
                </p>

                <h2 className="text-2xl font-bold text-navy-900 mt-8 mb-4">
                  Detail Perkembangan
                </h2>

                <p className="mb-4">
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem 
                  accusantium doloremque laudantium, totam rem aperiam, eaque ipsa 
                  quae ab illo inventore veritatis et quasi architecto beatae vitae 
                  dicta sunt explicabo.
                </p>

                <blockquote className="border-l-4 border-navy-900 pl-6 italic text-navy-600 my-6">
                  "Ini adalah quote penting dari narasumber yang memberikan konteks 
                  tambahan tentang berita yang sedang dibahas."
                </blockquote>

                <p className="mb-4">
                  Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit 
                  aut fugit, sed quia consequuntur magni dolores eos qui ratione 
                  voluptatem sequi nesciunt.
                </p>
              </div>

              {/* Tags */}
              <div className="mt-8 pt-8 border-t border-navy-100">
                <h3 className="text-sm font-semibold text-navy-900 mb-3">Tags:</h3>
                <div className="flex flex-wrap gap-2">
                  {['Malang', 'Berita', article.category, 'Update'].map((tag) => (
                    <a
                      key={tag}
                      href={`/tag/${tag.toLowerCase()}`}
                      className="px-3 py-1 bg-navy-50 text-navy-700 rounded-full text-sm hover:bg-navy-100 transition-colors"
                    >
                      #{tag}
                    </a>
                  ))}
                </div>
              </div>

              {/* Comments Section Placeholder */}
              <div className="mt-12 pt-8 border-t border-navy-100">
                <h3 className="text-xl font-bold text-navy-900 mb-6 flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  Komentar (12)
                </h3>
                <div className="bg-navy-50 rounded-xl p-6 text-center">
                  <p className="text-navy-600">Sistem komentar akan segera hadir</p>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <aside className="hidden lg:block w-80">
              {/* Author Card */}
              <div className="bg-navy-50 rounded-xl p-6 mb-6">
                <h3 className="font-bold text-navy-900 mb-4">Tentang Penulis</h3>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 bg-navy-200 rounded-full flex items-center justify-center">
                    <User className="h-6 w-6 text-navy-700" />
                  </div>
                  <div>
                    <p className="font-semibold text-navy-900">{article.author}</p>
                    <p className="text-sm text-navy-600">Jurnalis Senior</p>
                  </div>
                </div>
                <p className="text-sm text-navy-600">
                  Menulis sejak 2018 dengan fokus pada isu-isu {article.category} di Malang Raya.
                </p>
              </div>

              {/* Related Articles */}
              <div className="bg-white border border-navy-100 rounded-xl p-6">
                <h3 className="font-bold text-navy-900 mb-4">Berita Terkait</h3>
                <div className="space-y-4">
                  {relatedArticles.map((related) => (
                    <a
                      key={related.id}
                      href={`/artikel/${related.slug}`}
                      className="block group"
                    >
                      <div className="flex gap-3">
                        <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                          <img
                            src={related.coverImage}
                            alt={related.title}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                          />
                        </div>
                        <div>
                          <span className="text-xs text-navy-600">{related.category}</span>
                          <h4 className="text-sm font-semibold text-navy-900 line-clamp-2 group-hover:text-navy-700">
                            {related.title}
                          </h4>
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </article>

      <Footer />
    </main>
  )
}
