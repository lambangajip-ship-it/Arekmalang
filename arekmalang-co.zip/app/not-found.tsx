import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Home, Search, ArrowLeft } from "lucide-react"

export default function NotFound() {
  return (
    <main className="min-h-screen bg-white">
      <Navigation />

      <section className="py-20 md:py-32">
        <div className="container mx-auto px-4 text-center">
          {/* 404 Illustration */}
          <div className="relative w-48 h-48 mx-auto mb-8">
            <div className="absolute inset-0 bg-navy-100 rounded-full opacity-50 animate-pulse"></div>
            <div className="absolute inset-4 bg-navy-200 rounded-full opacity-50"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-7xl font-bold text-navy-900">404</span>
            </div>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            Halaman Tidak Ditemukan
          </h1>
          <p className="text-navy-600 text-lg max-w-md mx-auto mb-8">
            Maaf, halaman yang Anda cari tidak dapat ditemukan. Mungkin telah dipindahkan atau dihapus.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              asChild
              className="bg-navy-900 hover:bg-navy-800 px-8"
            >
              <a href="/" className="flex items-center gap-2">
                <Home className="h-4 w-4" />
                Kembali ke Beranda
              </a>
            </Button>
            <Button 
              asChild
              variant="outline"
              className="border-navy-200 hover:bg-navy-50 px-8"
            >
              <a href="/cari" className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                Cari Berita
              </a>
            </Button>
          </div>

          {/* Quick Links */}
          <div className="mt-12 pt-8 border-t border-navy-100 max-w-2xl mx-auto">
            <h3 className="text-sm font-semibold text-navy-900 mb-4 uppercase tracking-wider">
              Mungkin Anda Mencari:
            </h3>
            <div className="flex flex-wrap justify-center gap-3">
              {['Nasional', 'Daerah', 'Politik', 'Ekonomi', 'Olahraga', 'Teknologi'].map((cat) => (
                <a
                  key={cat}
                  href={`/kategori/${cat.toLowerCase()}`}
                  className="px-4 py-2 bg-navy-50 text-navy-700 rounded-full text-sm hover:bg-navy-100 transition-colors"
                >
                  {cat}
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
